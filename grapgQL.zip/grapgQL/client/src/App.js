import logo from './logo.svg';
import './App.css';
import {gql, useQuery} from "@apollo/client";

//  GetTodos - Optional name  
const query = gql`
  query GetTodos{  
    getTodos {
      id
      completed
      title
      user {
        id
        name
      }
    }
  }
`

function App() {
  const {data, loading} = useQuery(query);
  if(loading){
    return <h4>Loading....</h4>
  }
  return (
    <div>
      {<p>{JSON.stringify(data)}</p>}
    </div>
  );
}

export default App;
