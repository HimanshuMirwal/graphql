const express =require('express');
const {ApolloServer} = require("@apollo/server");
const {expressMiddleware} = require("@apollo/server/express4");
const bodyparser = require("body-parser");
const cors = require("cors");
const axios = require("axios").default;
const PORT = 8000;
async function startServer(){
    const app = express();
    const graphQLServer = new ApolloServer({
        typeDefs:`
            type Users {
                id: ID!
                name: String!
                username: Boolean
                email: String!
                phone: String!
                website: String!
            }

            type todo {
                id: ID!
                title: String!
                completed: Boolean
                userId: ID!
                user:Users
            }

            type Query {
                getTodos: [todo]
                getUsers: [Users]
                getUserById(id : ID!): Users
            }
        `,
        resolvers:{
            todo:{
                user:async (todo)=>(await axios.get(`https://jsonplaceholder.typicode.com/users/${todo.id}`)).data
            },
            Query: {
                getTodos : async ()=>(await axios.get("https://jsonplaceholder.typicode.com/todos")).data,
                getUsers : async ()=>(await axios.get("https://jsonplaceholder.typicode.com/users")).data,
                getUserById : async (parent, {id})=>(await axios.get(`https://jsonplaceholder.typicode.com/users/${id}`)).data,

            }
        }
    });
    app.use(bodyparser.json());
    app.use(cors());
    await graphQLServer.start();
    app.use("/graphql",expressMiddleware(graphQLServer));
    app.listen(PORT,()=>console.log(`Server started on ${PORT}`));
}
startServer();